$.Event('close.bs.alert')
$.Event('show.bs.modal')