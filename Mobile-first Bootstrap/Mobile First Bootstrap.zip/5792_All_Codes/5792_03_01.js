$(function(){
	if($.support.transition){ that.$element.addClass('fade in') }
});