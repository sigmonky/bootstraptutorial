If($.browser.msie) {
	//dummy for IE
}