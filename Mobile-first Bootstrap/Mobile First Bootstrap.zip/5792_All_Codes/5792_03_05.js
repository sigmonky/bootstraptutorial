$(document).ready(function(){
	if($.responsiveHub("isTouch")) {
	  giveTouch();
	}
});