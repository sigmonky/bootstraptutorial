$(document).on('click.bs.carousel.data-api', '[data-slide], [data-slide-to]', function (e) {
	// some javascript logic
});