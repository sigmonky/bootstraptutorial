See documentation in DOCS/documentation.html

<!-- BOOTSTARTER premium Bootstrap html5 template v 1.0.0. 

ArtLabs 2013 - 
http://www.bootstraptor.com

####### Released under GNU GENERAL PUBLIC LICENSE
 Version 2 ############ -->