See documentation in DOCS/documentation.html

<!-- BOOTSCROLLER premium Bootstrap html5 template v 1.0.0. 

ArtLabs 2013 - 
http://www.sitediscount.ru 

####### Released under GNU GENERAL PUBLIC LICENSE
 Version 2 ############ -->